#ifndef __AFFICHE_ATTRIBUT__
#define __AFFICHE_ATTRIBUT__

	#include <MLV/MLV_all.h>

	#include "equipement.h"
	#include "potion.h"
	#include "perso.h"
	#include "terrain.h"
	#include "tresor.h"
	#include "boolean.h"
	#include "musique.h"
	#include "graphique.h"
	#include "taille.h"


#endif