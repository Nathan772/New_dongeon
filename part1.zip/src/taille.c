#include "../inc/taille.h"

void vide(void){
	return;
}